var N = null;var sourcesIndex = {};
sourcesIndex["clup"] = {"name":"","dirs":[{"name":"api","files":["account.rs","dev.rs","shop.rs","staff.rs","ticket.rs"]},{"name":"models","files":["account.rs","customer.rs","shop.rs","staff.rs","ticket.rs"]},{"name":"utils","files":["encoding.rs","session.rs","tests.rs","time.rs"]}],"files":["api.rs","lib.rs","migrations.rs","models.rs","utils.rs"]};
sourcesIndex["main"] = {"name":"","files":["main.rs"]};
createSourceSidebar();
