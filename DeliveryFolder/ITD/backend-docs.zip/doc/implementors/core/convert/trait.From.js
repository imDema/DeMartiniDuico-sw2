(function() {var implementors = {};
implementors["clup"] = [{"text":"impl From&lt;Ticket&gt; for TicketResponse","synthetic":false,"types":[]},{"text":"impl From&lt;Department&gt; for DepartmentResponse","synthetic":false,"types":[]}];
if (window.register_implementors) {window.register_implementors(implementors);} else {window.pending_implementors = implementors;}})()