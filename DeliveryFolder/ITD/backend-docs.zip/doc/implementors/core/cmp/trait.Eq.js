(function() {var implementors = {};
implementors["clup"] = [{"text":"impl Eq for Account","synthetic":false,"types":[]},{"text":"impl Eq for Ticket","synthetic":false,"types":[]}];
if (window.register_implementors) {window.register_implementors(implementors);} else {window.pending_implementors = implementors;}})()